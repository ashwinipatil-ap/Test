<?php
$id = $_REQUEST['cid'];
include "../header.php";
include "../access_data.php";
$data = fetch_data_by_id($id);
//echo "<pre>"; print_r($data);die;
 ?>
   	<div class="container">
   		<div class="row mt-4">
		   	<div class="col-sm-10 mg-content">Edit Details</div>
		</div>
		<form name="edit_data" method="post" id="edit_data" action="edit_details.php" enctype="multipart/form-data">

		   <div class="col-sm-8">
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Tab Name:</lable>
		   		</div>
		   		<div class="col-sm-8">
		   			<input class="form-control" type="text" name="tab_name" value="<?php echo $data['tab_name']; ?>"/>
		   		</div>
		   	</div>
		   	<br>
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Tab Icon:</lable>
		   		</div>
		   		<div class="col-sm-6">
		   			<input name="tab-icon" type='file' data-img="blah" onchange="readURL(this,'blah');" />
		   		</div>
		   		<div class="col-sm-2">
		   			<img id="blah" src="<?php echo icon_access_path.$data['tab_icon'];?>" style="width: 100px; height:40px;">
		   		</div>
		   	</div>
		   	<br>
		   	
		   	<?php 
		   	$slider_content = json_decode($data['slider_content'],1);
		   	$slider_image   = json_decode($data['slider_image'],1);
		   	$count = count($slider_content); ?>
		   	<input type="hidden" id="count" value="<?php echo $count+1; ?>">
		   	<input type="hidden" name="id" value="<?php echo $data['id']; ?>">
		   	<?php foreach ($slider_content as $key => $value) { 
		   		$sel_id = 'sld_'.$key+1;
		   		if($key == $count-1){ ?>
		   			<div class="row content-col">
		   		<?php }else{ ?>
		   			<div class="row">
		   	    <?php } ?>
		   		<div class="col-sm-4">
		   			<lable>Column 2 Slider <?php echo $key+1; ?> Content:</lable>
		   		</div>
		   		<div class="col-sm-7">
	   			 <textarea class="form-control" rows="4" cols="50" name="slider_content[]"><?php echo $value; ?>
				 </textarea>
			    </div>
				<div class="col-sm-1">
					<!-- <?php if($key == 0){ ?>
					<button type="button" class="btn btn-danger add-btn">Add</button>
					<?php }else{ ?>
					<button type="button" class="btn btn-danger remove-btn">Remove</button>
					<?php } ?> -->
			    </div>
			    </div>
			    <br>
		   	<?php } ?>
		   	
		   	<?php foreach ($slider_image as $k1 => $val1) { 
		   		$sel_id = 'sld_'.$key+1;
		   		if($k1 == $count-1){ ?>
		   			<div class="row slider_img">
		   		<?php }else{ ?>
		   			<div class="row">
		   		<?php } ?>
		   		<div class="col-sm-4">
		   			<lable>Column 3 Slider <?php echo $k1+1; ?> Image:</lable>
		   		</div>
		   		<div class="col-sm-6">
		   			<input name="slider_image[]" type='file' multiple onchange="readURL(this,$sel_id);" />
		   		</div>
		   		<div class="col-sm-2">
		   			<img id="<?php echo $sel_id; ?>" src="<?php echo slider_access_path.$slider_image[$k1];?>" style="width: 100px; height:40px;">
		   		</div>
		   	</div>
		   	<br>
		   	<?php } ?>
		   	
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Status:</lable>
		   		</div>
		   		<div class="col-sm-8">
		   			 <select class="form-control" name="status">
		   			 	<?php if($data['status'] == 1){ ?>
		   			 		<option value="1" selected>Active</option>
					  		<option value="0">Inactive</option>
		   			 	<?php }else{ ?>
		   			 		<option value="1">Active</option>
					  		<option value="0" selected>Inactive</option>
		   			 	<?php } ?>
		   			 	
					</select> 
		   		</div>
		   	</div>
		   	<br>
		   </div>
		   <div class="row">
   			<div class="col-sm-2">
   				<button type="submit" class="btn btn-danger">Edit Details</button>
   			</div>
   			<div class="col-sm-2">
   				<button type="reset" class="btn btn-danger">Reset</button>
   			</div>
   			<div class="col-sm-2">
   				<button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger">Back</button>
   			</div>
   		</div>
		</form>
   	</div>
<?php
include "../footer.php";
 ?>
 <style type="text/css">
 	.mg-content{
 		font-weight: bold;
 	}
 </style>
 <script type="text/javascript">
 	var contentCont = $('#count').val();
 	var imgCont = $('#count').val();
   function readURL(input,id) {
   	alert("id"+id)
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#'+id)
                	.removeClass('d-none')
                    .attr('src', e.target.result)
                    .width(50)
                    .height(70);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    $(document).ready(function(){
    	//==============Add Contents========================
    	$('.add-btn').on('click',function(){
    		//Content
    		var addContent = '';
    		addContent = '<br><div class="row mt-2"><div class="col-sm-4"> <lable>Column 2 Slider '+contentCont+' Content:</lable></div><div class="col-sm-7"><textarea class="form-control" rows="4" cols="50" name="slider_content[]"></textarea></div><div class="col-sm-1"><button type="button" class="btn btn-danger remove-btn">Remove</button></div></div>';
    		$('.content-col').append(addContent);
    		contentCont++;
    		//Image
    		var add_img = '';
    		var sld_id = 'sld_'+imgCont;
    		add_img = '<div class="row mt-2 slider_img'+imgCont+'"><div class="col-sm-4"> <lable>Column3 Slider '+imgCont+' Image:</lable></div><div class="col-sm-6"> <input name="slider_image[]" multiple type="file"/></div><div class="col-sm-2"> <img id="sld_'+imgCont+'" class="d-none" src="#" alt=""/></div></div><br>';
    		$('.slider_img').append(add_img);
    		imgCont++;
    	});
    	$('.remove-btn').on('click',function(){
    	alert("remove")
    	});
    });
</script>