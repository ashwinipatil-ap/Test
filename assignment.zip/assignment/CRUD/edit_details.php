<?php
session_start();
$id = $_POST['id'];
include "../access_data.php";
$existing_data = fetch_data_by_id($id);

if(isset($_FILES['tab-icon']['name']) && !empty($_FILES['tab-icon']['name'])){
	$TabIconpath = 'tab_icon/'; // Upload directory for Tab Images
	if(move_uploaded_file($_FILES['tab-icon']['tmp_name'], $TabIconpath.$_FILES['tab-icon']['name'])){
		$tab_icon = $_FILES['tab-icon']['name'];
	}
}else{
	$tab_icon = $existing_data['tab_icon'];
}

foreach ($_POST['slider_content'] as $k => $val) {
	$slider_content[] = trim($val);
}

$img_index = 0;
$slider_images = json_decode($existing_data['slider_image'],1);
$path = 'slider_images/'; // Upload directory for slider Images
foreach ($_FILES['slider_image']['name'] as $f => $name) {
	if(isset($_FILES['slider_image']['name'][$img_index]) && !empty($_FILES['slider_image']['name'][$img_index])){
		if(move_uploaded_file($_FILES['slider_image']['tmp_name'][$img_index], $path.$_FILES['slider_image']['name'][$img_index])){
		$img_name = $_FILES['slider_image']['name'][$img_index];
		$upload_name[] = $img_name;
	}
	}else{
		$upload_name[] = $slider_images[$img_index];
	}
	$img_index++;
}
$data['tab_name'] = $_POST['tab_name'];
$data['status']   = $_POST['status'];
$data['tab_icon'] = $tab_icon;
$data['slider_image'] = json_encode($upload_name);
$data['slider_content'] = json_encode($slider_content);
$data['updated_on'] = date('Y-m-d H:i:s');
include "../database_connection.php";

//=================Inserting data====================
$query = "UPDATE tbl_manage_tab_content
			SET tab_name = '".$data['tab_name']."',tab_icon = '".$data['tab_icon']."',slider_content='".$data['slider_content']."',slider_image='".$data['slider_image']."',status='".$data['status']."',updated_on='".$data['updated_on']."'
			WHERE id = '".$id."'";
$retval = mysql_query( $query, $conn );
$_SESSION['status_flag'] = 2;
echo "<script>window.open('view.php','_self')</script>";





// session_start();
// $valid_formats = array('jpg', 'png', 'gif');
// $max_file_size = 1024*5000; //100 kb
// $path = 'slider_images/'; // Upload directory for slider Images
// $count = 0;
// foreach ($_FILES['slider_image']['name'] as $f => $name) {
// if ($_FILES['slider_image']['error'][$f] == 4) {
// continue; // Skip file if any error found
// }
// if ($_FILES['slider_image']['error'][$f] == 0) {
// if ($_FILES['slider_image']['size'][$f] > $max_file_size) {
// $message[] = $name.' is too large!.';
// continue; // Skip large files
// }
// elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
// $message[] = $name.' is not a valid format';
// continue; // Skip invalid file formats
// }
// else{ // No error found! Move uploaded files
// if(move_uploaded_file($_FILES['slider_image']['tmp_name'][$f], $path.$name))
// $count++; // Number of successfully uploaded file
// $upload_name[] = $name;
// }
// }
// }
// $TabIconpath = 'tab_icon/'; // Upload directory for Tab Images
// if(move_uploaded_file($_FILES['tab-icon']['tmp_name'], $TabIconpath.$_FILES['tab-icon']['name'])){
// 	$tab_icon = $_FILES['tab-icon']['name'];
// }
// $data['tab_name'] = $_POST['tab_name'];
// $data['status']   = $_POST['status'];
// $data['tab_name'] = $_POST['tab_name'];
// $path = 'tab_icon/';
// if(move_uploaded_file($_FILES['tab-icon'], $path.$_FILES['tab-icon']['name'])){
// 	$tab_icon = $_FILES['tab-icon']['name'];
// }

// foreach ($_POST['slider_content'] as $k => $val) {
// 	$slider_content[] = trim($val);
// }
// $data['tab_icon'] = $tab_icon;
// $data['slider_image'] = json_encode($upload_name);
// $data['slider_content'] = json_encode($slider_content);
// $data['created_on'] = date('Y-m-d H:i:s');
// include "../database_connection.php";
// //=================Inserting data====================
// $query = "INSERT INTO tbl_manage_tab_content (id,tab_name,tab_icon,slider_content,slider_image,status,created_on) VALUES (NULL,'".$data['tab_name']."','".$data['tab_icon']."','".$data['slider_content']."','".$data['slider_image']."','".$data['status']."','".$data['created_on']."')";
// $retval = mysql_query( $query, $conn );
// $_SESSION['status_flag'] = 1;
// echo "<script>window.open('view.php','_self')</script>";
?>