<?php
include "../header.php";
 ?>
   	<div class="container">
   		<div class="row mt-4">
		   	<div class="col-sm-10 mg-content">Add Details</div>
		</div>
		<form name="create_data" method="post" id="create_data" action="access_data.php" enctype="multipart/form-data">

		   <div class="col-sm-8">
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Tab Name:</lable>
		   		</div>
		   		<div class="col-sm-8">
		   			<input class="form-control" type="text" name="tab_name" value=""/>
		   		</div>
		   	</div>
		   	<br>
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Tab Icon:</lable>
		   		</div>
		   		<div class="col-sm-6">
		   			<input name="tab-icon" type='file' data-img="blah" onchange="readURL(this,'blah');" />
		   		</div>
		   		<div class="col-sm-2">
		   			<img id="blah" class="d-none" src="#" alt=""/>
		   		</div>
		   	</div>
		   	<br>
		   	<div class="row content-col">
		   		<div class="col-sm-4">
		   			<lable>Column2 Slider1 Content:</lable>
		   		</div>
		   		<div class="col-sm-7">
	   			 <textarea class="form-control" rows="4" cols="50" name="slider_content[]">
				 </textarea>
			    </div>
				<div class="col-sm-1">
				 <button type="button" class="btn btn-danger add-btn">Add</button> 
			    </div>
		   	</div>
		   	<br>
		   	<div class="row slider_img">
		   		<div class="col-sm-4">
		   			<lable>Column3 Slider1 Image:</lable>
		   		</div>
		   		<div class="col-sm-6">
		   			<input name="slider_image[]" type='file' multiple onchange="readURL(this,'sld_1');" />
		   		</div>
		   		<div class="col-sm-2">
		   			<img id="sld_1" class="d-none" src="#" alt=""/>
		   		</div>
		   	</div>

		   	<br>
		   	<div class="row">
		   		<div class="col-sm-4">
		   			<lable>Status:</lable>
		   		</div>
		   		<div class="col-sm-8">
		   			 <select class="form-control" name="status">
		   			 	<option value="1">Active</option>
					  	<option value="0">Inactive</option>
					</select> 
		   		</div>
		   	</div>
		   	<br>
		   </div>
		   <div class="row">
   			<div class="col-sm-2">
   				<button type="submit" class="btn btn-danger">Add Details</button>
   			</div>
   			<div class="col-sm-2">
   				<button type="reset" class="btn btn-danger">Reset</button>
   			</div>
   			<div class="col-sm-2">
   				<button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger">Back</button>
   			</div>
   		</div>
		</form>
   	</div>
<?php
include "../footer.php";
 ?>
 <style type="text/css">
 	.mg-content{
 		font-weight: bold;
 	}
 </style>
 <script type="text/javascript">
 	var contentCont = 2;
 	var imgCont = 2;
   function readURL(input,id) {
   	alert("id"+id)
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#'+id)
                	.removeClass('d-none')
                    .attr('src', e.target.result)
                    .width(50)
                    .height(70);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }

    $(document).ready(function(){
    	//==============Add Contents========================
    	$('.add-btn').on('click',function(){
    		//Content
    		var addContent = '';
    		addContent = '<br><div class="row mt-2"><div class="col-sm-4"> <lable>Column 2 Slider '+contentCont+' Content:</lable></div><div class="col-sm-7"><textarea class="form-control" rows="4" cols="50" name="slider_content[]"></textarea></div><div class="col-sm-1"><button type="button" class="btn btn-danger remove-btn">Remove</button></div></div>';
    		$('.content-col').append(addContent);
    		contentCont++;
    		//Image
    		var add_img = '';
    		var sld_id = 'sld_'+imgCont;
    		add_img = '<div class="row mt-2 slider_img'+imgCont+'"><div class="col-sm-4"> <lable>Column3 Slider '+imgCont+' Image:</lable></div><div class="col-sm-6"> <input name="slider_image[]" multiple type="file"/></div><div class="col-sm-2"> <img id="sld_'+imgCont+'" class="d-none" src="#" alt=""/></div></div><br>';
    		$('.slider_img').append(add_img);
    		imgCont++;
    	});
    	$('.remove-btn').on('click',function(){
    	alert("remove")
    	});
    });
</script>