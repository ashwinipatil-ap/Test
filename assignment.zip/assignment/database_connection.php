<?php 
	$servername = "localhost";
	$username   = "root";
	$password   = "root";
	// Create connection
	$conn = mysql_connect($servername, $username, $password);
	 mysql_select_db('test');
	// Check connection
	///echo "conn->>>>"; print_r($conn);die;
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	
 ?>
