<?php 
    include "header.php";
    include "access_data.php";
    $data = get_data();
?>
<br>

<div class="container" id="web">
  <div class="text-center mb-4 mt-5">
    <h2 class="text-white mb-3">DelphianLogic in Action</h2>
    <h6 class="text-white">Welcome to the World of DelphianLogic. Start Learning...</h6>
  </div>
  <br>
  <!-- Nav tabs -->
  <div class="row">
  <div class="col-sm-3" style="background-color: #fff; padding-top: 15px;">
    <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
      <?php foreach ($data as $key => $value) {
        $id = 'v-pills-'.$value['tab_name'];
        $href = '#v-pills-'.$value['tab_name'];
        $labelledby = 'v-pills-'.$value['tab_name'].'-tab';
        if($key == 0){ ?>
          <a class="nav-link active tab-names" data-tabname="<?php echo $value['tab_name']; ?>" id="<?php echo $labelledby; ?>" data-toggle="pill" href="<?php echo $href; ?>" role="tab" aria-controls="<?php echo $id; ?>" aria-selected="true"><span> <img src="<?php echo icon_access_path.$value['tab_icon']; ?>" style="width:10%"></span>&nbsp;&nbsp;&nbsp; <?php echo $value['tab_name']; ?></a>
        <?php }else{ ?>



          <div class="" >
            <div id="demo" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="active select-slider column2-indicator"></li>
                      <?php }else{ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="select-slider column2-indicator"></li>
                      <?php } } ?>
                </ul>
                <div class="carousel-inner slider_1"> <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <div class="carousel-item active">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                      <?php }else{ ?>
                       <div class="carousel-item">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                  <?php } } ?>
                </div>
              </div>
          </div>



          <a class="nav-link tab-names" data-tabname="<?php echo $value['tab_name']; ?>" id="<?php echo $labelledby; ?>" data-toggle="pill" href="<?php echo $href; ?>" role="tab" aria-controls="<?php echo $id; ?>" aria-selected="true"><span> <img src="<?php echo icon_access_path.$value['tab_icon']; ?>" style="width:10%"></span>&nbsp;&nbsp;&nbsp; <?php echo $value['tab_name']; ?></a>
       <?php } } ?>
    </div>
  </div>
  <div class="col-sm-9 media-block">
            <?php 
            $count = count($data);
            foreach ($data as $key => $value) { 
              $id = 'v-pills-'.$value['tab_name'];
              $labelledby = 'v-pills-'.$value['tab_name'].'-tab'; ?>
              <?php if($key == 0){ ?>
                <div class="row">
                <div class="col-sm-6 back">
                  <div class="tab-content" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="<?php echo $id; ?>" role="tabpanel" aria-labelledby="<?php echo $labelledby; ?>">
              <?php }else{ ?>
                <div class="tab-pane fade show" id="<?php echo $id; ?>" role="tabpanel" aria-labelledby="<?php echo $labelledby; ?>">
              <?php } ?>
             
              <div id="demo" class="carousel slide" data-ride="carousel">
                <ul class="carousel-indicators">
                  <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="active select-slider column2-indicator"></li>
                      <?php }else{ ?>
                        <li data-target="#demo" data-tabname="<?php echo $value['tab_name']; ?>" data-slide-to="<?php echo $k; ?>" class="select-slider column2-indicator"></li>
                      <?php } } ?>
                </ul>
                <div class="carousel-inner slider_1"> <?php 
                    $slider_content = json_decode($value['slider_content'],1);
                    foreach ($slider_content as $k => $val) {
                      if($k == 0){ ?>
                        <div class="carousel-item active">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                      <?php }else{ ?>
                       <div class="carousel-item">
                          <img src="https://via.placeholder.com/468x312/6abbd8/808080?text=+" alt="Chicago" style="width:100%">
                          <div class="carousel-caption">
                            <p><?php echo $val; ?></p>
                          </div>   
                        </div>
                  <?php } } ?>
                </div>
              </div>
            </div>
            <?php 
              if($key == $count-1){ ?>
                </div>
              </div>
              <?php foreach ($data as $slide_key => $slide_value) { 
                $slider_img = json_decode($slide_value['slider_image'],1);
                if($slide_key == 0){ ?>
                  <div class="col-sm-6 back slide-imgs" id="<?php echo $slide_value['tab_name']; ?>">
                <?php }else{ ?>
                   <div class="col-sm-6 back slide-imgs" id="<?php echo $slide_value['tab_name']; ?>" style="display:none;">
                <?php } 
                foreach ($slider_img as $slide_key1 => $slide_value1) {
                $id1 = $slide_value['tab_name'].$slide_key1;  
                  if($slide_key1 == 0){ ?>
                    <img id="<?php echo $id1; ?>" src="<?php echo slider_access_path.$slide_value1; ?>" alt="New York" style="width:100%" class="column3-image">
                  <?php }else{ ?>
                    <img id="<?php echo $id1; ?>" src="<?php echo slider_access_path.$slide_value1; ?>" alt="New York" style="width:100%;display:none;" class="column3-image">
                  <?php } ?>
                  
               <?php } ?>
             </div>
              <?php } ?>
          </div>
              <?php }
             } ?>
 </div>
</div>
</div>



<?php include "footer.php"; ?>

<style type="text/css">
.back{
  background-color: #ccc;
  padding: 0;
}
.carousel-indicators li{
  width: 10px;
  height: 10px;
  border-radius: 50px!important;
  border: none;
}
.nav-pills .nav-link.active, .nav-pills .show > .nav-link {
    color: #000;
    background-color: #fff;
    border: 1px solid #ccc;
    box-shadow: 3px 3px 5px #ccc;
    font-size: 0.9em;
    border-radius: 0!important;
}
.nav-pills .nav-link{
  font-size: 0.9em;
  color: #000;
  background-color: #fff;
  margin-bottom: 10px!important;
}
body{
  background-color: #143577;
}
.nav-link {
    display: block;
    padding: 1rem 1rem;
}
</style>

<script type="text/javascript">
  $(document).ready(function(){
     $('.column2-indicator').on('click',function(){
      var slide_cnt;
      var total_slide_cnt;
      var tabname = $(this).attr('data-tabname');
      $('.column3-image').hide();
      slide_cnt = $(this).attr('data-slide-to');
      var id = tabname+slide_cnt;
      $('#'+id).removeAttr("style");
      $('#'+id).css("width","100%");
    });

     $('.tab-names').on('click',function(){
      var tabname = $(this).attr('data-tabname');
      var id = tabname+'0';
      $('.slide-imgs').hide();
      $('#'+tabname).show();
      $('#'+id).removeAttr("style");
      $('#'+id).css("width","100%");  
     });

    // $('#demo').on('change',function(){
    //   alert("Hello");
    //   // var slide_cnt;
    //   // var total_slide_cnt;
    //   // $('.column3-image').hide();
    //   // slide_cnt = $(this).attr('data-slide-to');
    //   // $('#'+slide_cnt).removeAttr("style");
    //   // $('#'+slide_cnt).css("width","100%");
    // });
    
  });

</script>
<style type="text/css">
@media only screen and (max-width: 416px) {
  .media-hide {
      display: none!important;
  }
  .media-block {
        display: block!important;
    }
}
</style>