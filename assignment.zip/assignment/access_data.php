<?php
	// function __construct() {
	//     //*********Accessing Database*********************
	// 	$servername = "localhost";
	// 	$username   = "root";
	// 	$password   = "root";
	// 	// Create connection
	// 	$conn = mysql_connect($servername, $username, $password);
	// 	 mysql_select_db('test');
	// 	// Check connection
	// 		if ($conn->connect_error) {
	// 		    die("Connection failed: " . $conn->connect_error);
	// 		}
 //    }

	function fetch_data_by_id($id){
		include "../database_connection.php";
		$query  = 'SELECT * FROM tbl_manage_tab_content WHERE id="'.$id.'"';
		$retval = mysql_query( $query, $conn ) or die(mysql_error());
		$result = mysql_fetch_assoc($retval);
		return $result;
	}

	function delete_record($id){
		echo "<pre>delete_record"; print_r($id); die;
	}
	

	function fetch_data(){
	include "../database_connection.php";

	$query  = 'SELECT * FROM tbl_manage_tab_content';
	$retval = mysql_query( $query, $conn ) or die(mysql_error());
	$result = '';
	while ($row = mysql_fetch_assoc($retval)) {
	    $result[] = $row;
	}
	return isset($result)?$result:'';
	}

	function get_data(){
	include "database_connection.php";

	$query  = 'SELECT * FROM tbl_manage_tab_content';
	$retval = mysql_query( $query, $conn ) or die(mysql_error());
	$result = '';
	while ($row = mysql_fetch_assoc($retval)) {
	    $result[] = $row;
	}
	return isset($result)?$result:'';
	}

?>